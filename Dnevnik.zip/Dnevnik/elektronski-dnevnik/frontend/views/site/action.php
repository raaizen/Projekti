<?php 
print_r($controllers);
?>