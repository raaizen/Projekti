<?php
foreach($model as $teacher){
    echo $teacher->id.'-'.$teacher->first_name.'<br>';
    
}
?>