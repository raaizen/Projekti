<?php

$this->title = 'Update Schedule: {nameAttribute}';
$this->params['breadcrumbs'][] = ['label' => 'Schedules', 'url' => ['index']];
$this->params['breadcrumbs'][] = 'Update';
echo $msg;
?>